// postReducer.js
import { ADD_POST, EDIT_POST, DELETE_POST, LIKE_POST } from "../actions/postActionTypes";

const initialState = {
  posts: [ {
    id: "xGeFfcz4XTRhRXgZmsNfP",
    title: "React is trending!",
    category: "Technology",
    content: "In the IT sector, ReactJS is becoming more popular day by day. It has become one of the most preferred language for Frontend developers.",
    likes: 40,
    date: "2023-09-25T07:26:53.002Z"
  },
  {
    id: "AXzItcnEpv7fn76lE7wze",
    title: "Indian Travel Blog",
    category: "Travel",
    content: "Planning a vacation in India? Read the true Indian travel blogs from the real travelers who have experienced the tourist destinations in the country.",
    likes: 20,
    date: "2023-09-23T07:26:53.002Z",
  },
  {
    id: "p9aW_aw0JO6jsPZg8IwmE",
    title: "How To Get Paid To Travel",
    category: "Travel",
    content: "Wondering how to become a paid travel influencer? Thinking about what steps top travel influencers took to become what they are today? In this article, I am going to share some useful tips to help you learn it all.The following 4 tips will help you become a paid travel influencer:  1. Positioning Yourself  2. Work As A Freelancer  3. Have A killer Media Kit  4. Invest In Your Business",
    likes: 80,
    date: "2023-09-24T07:26:53.002Z",
  },
],
};

const postReducer = (state = initialState, action) => {
  switch (action.type) {
    case ADD_POST:
      return {
        ...state,
        posts: [...state.posts, action.payload]      
        };
    case EDIT_POST:
      return {
        ...state,
        posts: state.posts.map((post) =>
          post.id === action.payload.id ? action.payload : post
        ),
      };
    case DELETE_POST:
      return {
        ...state,
        posts: state.posts.filter((post) => post.id !== action.payload),
      };
    case LIKE_POST:
      return {
        ...state,
        posts: state.posts.map((post) =>
          post.id === action.payload
            ? { ...post, likes: post.likes + 1 }
            : post
        ),
      };
    default:
      return state;
  }
};

export default postReducer;
