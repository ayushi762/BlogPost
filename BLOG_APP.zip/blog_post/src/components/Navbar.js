// Navbar.js
import React, { useContext } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import '../style/Navbar.css';
import HomeScreenContext from '../context/homeScreenContext';

function Navbar() {
  const { isHomeScreen, setIsHomeScreen } = useContext(HomeScreenContext);
  const navigate = useNavigate();

  const handleNavigate = (path) => {
    if (isHomeScreen) {
      setIsHomeScreen(false);
    }
    else
     setIsHomeScreen(true);
    navigate(path);
  };

  return (
    <div className="navbar">
      <div className="container">
        <h2 className="navbar-logo">BlogMania</h2>
        <ul className="navbar-menu">
          {isHomeScreen ? (
            <>
              <li className="navbar-item">
                <Link to={'/post'} onClick={() => handleNavigate('/post')}>
                  New Post
                </Link>
              </li>
            </>
          ) : (
            <>
              <li className="navbar-item">
                <Link to={'/'} onClick={() => handleNavigate('/')}>
                  Home
                </Link>
              </li>
             
            </>
          )}
        </ul>
      </div>
    </div>
  );
}

export default Navbar;
