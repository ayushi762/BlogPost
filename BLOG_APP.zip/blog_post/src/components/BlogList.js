import React, { useContext } from 'react';
import { useSelector } from "react-redux";
import '../style/BlogList.css';
import { Link, useNavigate } from 'react-router-dom';
import HomeScreenContext from '../context/homeScreenContext';
import TimeAgo from './TimeAgo';

function BlogList() {

  const blogs = useSelector((state) => state.posts);
  const { isHomeScreen, setIsHomeScreen } = useContext(HomeScreenContext);

  const navigate = useNavigate();
  const handleNavigate = (path) => {
    if (isHomeScreen) {
      setIsHomeScreen(false);
    }
    navigate(path);
  };

  const sortedBlogs = blogs.slice().sort((a, b) => {
    return new Date(b.date) - new Date(a.date);
  });

  const truncateContent = (content) => {
    return content.length > 55 ? content.substring(0, 55) + '...' : content;
  };

  return (
    <div className="blog-list-container">
       {sortedBlogs.length === 0 ? (
        <div className="no-blogs-found">
          <p>No blogs are found. <Link to="/post">Add a post first!</Link></p>
        </div>
      ) : (
        sortedBlogs.map((blog) => (
          <div className="blog-item" key={blog.id}>
            <h2>{blog.title} </h2>
            <div className="title-row">
              <h6>{blog.category}</h6>
              <i className="fa fa-thumbs-up thumbs-up-icon">{blog.likes}</i>
            </div>
            <p>{truncateContent(blog.content)}</p>
            <p className="postCredit">
                <Link to={`/blog/${blog.id}`} className='viewLink' onClick={() => handleNavigate(`/blog/${blog.id}`)}>View Blog</Link>
                <TimeAgo timestamp={blog.date} />
            </p>
          </div>
        ))
      )}
      
    </div>
  );
};

export default BlogList;
