import React from "react";
import { useParams } from 'react-router-dom';
import { useSelector, useDispatch } from "react-redux";
import { Link} from 'react-router-dom';
import { deletePost, likePost } from "../actions/postActions";
import '../style/BlogDetail.css';
import { useContext } from "react";
import HomeScreenContext from '../context/homeScreenContext';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function BlogDetail(props) {
  const { id } = useParams();
  const dispatch = useDispatch();
  const { isHomeScreen, setIsHomeScreen } = useContext(HomeScreenContext);

  const blogs = useSelector((state) => state.posts);

  const blog = blogs.find((blog) => blog.id === id);

  const handleDeletePost = (postId) => {
    setIsHomeScreen(true);
    dispatch(deletePost(postId));
    toast.success('Blog Deleted Successfully!',{
      position: toast.POSITION.TOP_RIGHT,
      autoClose: 3000, 
      hideProgressBar: true, 
    });
  };

  return (
    <div className="center-container">
      
      {blog ? (
        <div className="blog-detail-container">
                <Link to="/" className="backBtn" onClick={() => setIsHomeScreen(true)}><i className="fa fa-chevron-left"></i></Link>
          <h2>{blog.title}</h2>
          <h6>{blog.category}</h6>
          <p>Likes: {blog.likes}</p>
          <p>{blog.content}</p>
          
        </div>
      ) : (
        <p>Blog not found</p>
      )}
      <ul className="dashboard-menu">
        <li className="dashboard-item">
          <Link to={`/post/${blog.id}`} className='fa fa-edit' > Edit </Link>
        </li>
        <li className="dashboard-item">
          <Link to={`/blog/${blog.id}`} onClick={() => dispatch(likePost(blog.id))} className="fa fa-thumbs-up">
            Like
          </Link>
        </li>
      <li className="dashboard-item">
        <Link to={'/'} className="fa fa-trash" onClick={() => handleDeletePost(blog.id)}>
          Delete
        </Link>
      </li>
      </ul>
    </div>
  );
}

export default BlogDetail;
