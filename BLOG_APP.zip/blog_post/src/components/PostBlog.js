// BlogPosts.js
//For posting and editing a blog
import React, { useState, useEffect, useContext } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { addPost, editPost } from '../actions/postActions';
import { useParams, useNavigate } from 'react-router-dom';
import { Link } from 'react-router-dom';
import '../style/PostBlog.css';
import HomeScreenContext from '../context/homeScreenContext';
import { nanoid } from '@reduxjs/toolkit';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

function BlogPosts() {
  const posts = useSelector((state) => state.posts);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const { id } = useParams();
  const { isHomeScreen, setIsHomeScreen } = useContext(HomeScreenContext);

  const isEditMode = !!id;

  const [formData, setFormData] = useState({
    id: '',
    title: '',
    category: '',
    content: '',
  });

  useEffect(() => {
    if (id && posts.length > 0) {
      const post = posts.find((post) => post.id === id);
      if (post) {
        setFormData({
          id: post.id,
          title: post.title,
          category: post.category,
          likes: post.likes,
          content: post.content,
          date: post.date,
        });
      }
    }
  }, [id, posts]);

  const canSave = Boolean(formData.title) && Boolean(formData.content) && Boolean(formData.category);

  const handleInputChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handlePostAction = (actionType) => {
    if (formData.title && formData.category && formData.content) {
      if (actionType === 'edit') {
        handleEditPost(formData);
      } else {
        handleAddPost();
      }
    };
  }

  const handleAddPost = () => {
      const currentDate = new Date().toISOString();

      const newPost = {
        id: nanoid(),
        title: formData.title,
        category: formData.category,
        content: formData.content,
        likes: 0,
        date: currentDate,
      };

      setIsHomeScreen(true);
      dispatch(addPost(newPost));
      toast.success('Blog Added Successfully!',{
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 3000, 
        hideProgressBar: true, 
      });
      navigate("/");
      setFormData({ id: '', title: '', category: '', content: '' });
  };

  const handleEditPost = (post) => {
      setIsHomeScreen(true);
      dispatch(editPost({ ...post, id: post.id }));
      toast.success('Blog Updated Successfully!',{
        position: toast.POSITION.TOP_RIGHT,
        autoClose: 3000, 
        hideProgressBar: true, 
      });
      navigate("/");
      setFormData({ id: '', title: '', category: '', content: '' });
  };

  return (
    <div className="center-container">
      <div className="blog-detail-container">
        <h1>Blog Posts</h1>

        <label htmlFor="title">Title</label>
        <input
          type="text"
          name="title"
          placeholder="Title"
          value={formData.title}
          maxLength={30} 
          onChange={handleInputChange}
        />
        <label htmlFor="category">Category</label>
        <input
          type="text"
          name="category"
          placeholder="Category"
          value={formData.category}
          onChange={handleInputChange}
        />
        <label htmlFor="content">Content</label>
        <textarea
          id="content"
          name="content"
          placeholder="Content"
          style={{ height: '100px' }}
          value={formData.content}
          onChange={handleInputChange}
        />
        <div className='linkContainer'>
          {isEditMode ? (
            <Link
              to={'/'}
              onClick={(e) => {
                e.preventDefault();
                handlePostAction('edit');
              }}
              className={`linkStyle linkStyleEditMode ${canSave ? '' : 'disabled'}`}
            >
              Update Post
            </Link>
          ) : (
            <Link
              to={'/'}
              onClick={(e) => {
                e.preventDefault();
                handlePostAction('add');
              }}
              className={`linkStyle ${canSave ? '' : 'disabled'}`}
            >
              Add Post
            </Link>
          )}
          <Link to="/" className='linkStyle' onClick={() => setIsHomeScreen(true)}>Cancel</Link>
        </div>
      </div>

    </div>
  );
}

export default BlogPosts;