const logger = store => next => action => {
    console.group(action.type)
    console.info('dispatching', action)
    let result = next(action)
    console.log('next state', store.getState())
    console.groupEnd()
    
     // Save the state to localStorage after each action
    const state = store.getState();
    localStorage.setItem('reduxState', JSON.stringify(state));
    
    return result
  }
  
  export default logger