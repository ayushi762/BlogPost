import './App.css';
import configureStore from './app/store';
import { Provider } from 'react-redux';
import { ToastContainer } from 'react-toastify';
import Routes from './routes';
import React from 'react';

const store = configureStore();

function App() {
  return (
      <Provider store={store}>
      <div className="App">
        <Routes />
        <ToastContainer />
      </div>
    </Provider>
  );
}

export default App;
