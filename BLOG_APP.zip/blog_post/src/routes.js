// Routes.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'; // Import Routes from react-router-dom
import BlogList from './components/BlogList';
import PostBlog from './components/PostBlog';
import BlogDetail from './components/BlogDetail';
import { HomeScreenProvider } from './context/homeScreenContext';
import Navbar from './components/Navbar';

function routes() {
  return (
    <Router>
      <HomeScreenProvider>
        <Navbar />
        <Routes>
          <Route exact path="/" element={<BlogList />} />
          <Route path="/post" element={<PostBlog />} />
          <Route path="/post/:id" element={<PostBlog />} />
          <Route path="/blog/:id" element={<BlogDetail />} />
        </Routes>
      </HomeScreenProvider>
    </Router>
  );
}

export default routes;
